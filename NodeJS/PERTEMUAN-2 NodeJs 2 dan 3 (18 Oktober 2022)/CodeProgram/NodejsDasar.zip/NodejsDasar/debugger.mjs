function sayHello(name){
    debugger;
    return `Hello ${name}`;
}

const name = "Eko";
console.info(sayHello(name));
