setTimeout(() => {
    console.info("Hello Globals");
}, 5000);