export const min = (first, second) => {
    if (first < second) {
        return first;
    } else {
        return second;
    }
}

export const max = (first, second) => {
    if (first > second) {
        return first;
    } else {
        return second;
    }
}
