import { writeToFile } from "NodeJs/write.js";

writeToFile("NamaPedagang.log", "Kang Asep");