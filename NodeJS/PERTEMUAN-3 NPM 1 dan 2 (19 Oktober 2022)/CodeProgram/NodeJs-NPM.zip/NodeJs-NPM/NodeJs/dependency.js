import _ from "lodash";

const source = "BUAH YANG SEHAT";
const target = _.capitalize(source);

console.info(target);