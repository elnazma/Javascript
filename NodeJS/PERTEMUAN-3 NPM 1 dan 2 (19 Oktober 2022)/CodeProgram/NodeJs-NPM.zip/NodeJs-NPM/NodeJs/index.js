import { writeToFile } from "./write.js";

writeToFile("buah.log", "Jambu");