import moment from "moment";

console.info(moment(), format());